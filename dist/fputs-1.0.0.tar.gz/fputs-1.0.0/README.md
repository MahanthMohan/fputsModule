# fputs

## Description
A simple package that extends the fputs C library function to Python, with the help of the Python C API

## Documentation (Methods)
`fputs(data, filename)`
A method that takes in 2 parameters - data and filename, to write data in the specified file

## Credits
Author - Mahanth Mohan
Email - mohan.mahanth@gmail.com
Feel free to reach out to me using this email to suggest any fixes/improvements
And also to contribute to this project!
